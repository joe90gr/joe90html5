<!DOCTYPE html>
<html>
	<head>
		<title>Test</title>
		<link rel="stylesheet" text="text/css" href="css/layout.css" />
		<script data-main="js/myscript" src="js/libs/jquery.js"></script>
		<script data-main="js/myscript" src="js/require.js"></script>
	</head>
	<body class="fire">
		<header>
			<div class="button-panel">
				<button>Button 1</button>
				<button>Button 2</button>
				<button>Button 3</button>
				<button>Button 4</button>
			</div>
		</header>
		<section>
			<div id="dump">If you see this Jquery is not working v2</div>	
			<div id="sidebar">yy</div>		
		</section>
		<footer>
			Footer Container.
		</footer>
	</body>
</html>